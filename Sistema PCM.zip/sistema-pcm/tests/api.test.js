'use strict';
// Testes da API: rode com  npm test
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { carregarConfig } = require('../backend/src/config');
const { criarApp } = require('../backend/src/app');

// ATENÇÃO: os testes APAGAM tudo do banco de testes. Por segurança, o nome desse banco
// precisa terminar em "_teste" (o padrão é pcm_teste, criado por banco/criar-banco.sql).
const BANCO_TESTE = process.env.DB_NAME_TESTE || 'pcm_teste';
if (!/_teste$/.test(BANCO_TESTE)) {
  throw new Error(`O banco de testes precisa terminar em "_teste" (recebido: "${BANCO_TESTE}").`);
}

let servidor, base, pasta, app;

async function limparBanco(db) {
  const cx = await db.getConnection();
  try {
    await cx.query('SET FOREIGN_KEY_CHECKS = 0');
    for (const t of ['os_historico', 'os', 'usuarios']) await cx.query(`TRUNCATE TABLE ${t}`);
    await cx.query('SET FOREIGN_KEY_CHECKS = 1');
  } finally {
    cx.release();
  }
}

test.before(async () => {
  pasta = fs.mkdtempSync(path.join(os.tmpdir(), 'pcm-teste-'));
  const config = carregarConfig({
    dataDir: pasta, jwtSecret: 'segredo-de-teste', porta: 0, limitarTentativas: false,
    db: { database: BANCO_TESTE },
  });
  app = await criarApp(config);
  await limparBanco(app.locals.db);
  await new Promise((ok) => { servidor = app.listen(0, '127.0.0.1', ok); });
  base = `http://127.0.0.1:${servidor.address().port}`;
});
test.after(async () => {
  servidor.closeAllConnections();
  servidor.close();
  await app.locals.db.end();
  fs.rmSync(pasta, { recursive: true, force: true });
});

async function chamar(metodo, rota, { token, corpo } = {}) {
  const r = await fetch(base + rota, {
    method: metodo,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  let json = null;
  try { json = await r.json(); } catch (e) { /* sem corpo */ }
  return { status: r.status, json };
}

const hoje = new Date();
function iso(d) { return d.toISOString().slice(0, 10); }
function maisDias(n) { const d = new Date(hoje); d.setUTCDate(d.getUTCDate() + n); return iso(d); }

const estado = {};

test('primeiro acesso cria o PCM uma única vez', async () => {
  let r = await chamar('GET', '/api/setup');
  assert.equal(r.json.configurado, false);
  r = await chamar('POST', '/api/setup', { corpo: { nome: 'Tiago PCM', matricula: 'PCM1', pin: '123456' } });
  assert.equal(r.status, 201);
  assert.equal(r.json.usuario.funcao, 'pcm');
  assert.equal(r.json.usuario.matricula, 'pcm1');
  estado.pcm = r.json.token;
  r = await chamar('POST', '/api/setup', { corpo: { nome: 'Invasor', matricula: 'x', pin: '1111' } });
  assert.equal(r.status, 409);
  r = await chamar('GET', '/api/setup');
  assert.equal(r.json.configurado, true);
});

test('login: PIN errado é recusado e o certo entra', async () => {
  let r = await chamar('POST', '/api/auth/login', { corpo: { matricula: 'pcm1', pin: '000000' } });
  assert.equal(r.status, 401);
  r = await chamar('POST', '/api/auth/login', { corpo: { matricula: 'naoexiste', pin: '123456' } });
  assert.equal(r.status, 401);
  assert.equal(r.json.erro, 'Matrícula ou PIN incorretos.');
  r = await chamar('POST', '/api/auth/login', { corpo: { matricula: 'PCM1', pin: '123456' } });
  assert.equal(r.status, 200);
  r = await chamar('GET', '/api/auth/eu', { token: r.json.token });
  assert.equal(r.json.usuario.nome, 'Tiago PCM');
  assert.equal(r.json.usuario.pin_hash, undefined);
});

test('PCM cadastra mecânico, eletricista e predial', async () => {
  const cadastrar = (nome, matricula, funcao, pin = '4321') =>
    chamar('POST', '/api/usuarios', { token: estado.pcm, corpo: { nome, matricula, funcao, pin } });
  let r = await cadastrar('Carlos Mecânico', 'carlos', 'mecanico');
  assert.equal(r.status, 201); estado.carlosId = r.json.usuario.id;
  r = await cadastrar('João Elétrica', 'joao', 'eletricista');
  assert.equal(r.status, 201); estado.joaoId = r.json.usuario.id;
  r = await cadastrar('Paulo Predial', 'paulo', 'predial');
  assert.equal(r.status, 201); estado.pauloId = r.json.usuario.id;
  assert.equal((await cadastrar('Outro', 'carlos', 'mecanico')).status, 409);
  assert.equal((await cadastrar('Pin curto', 'zeca', 'mecanico', '12')).status, 400);
  assert.equal((await cadastrar('Função falsa', 'zeca', 'chefe')).status, 400);
  assert.equal((await cadastrar('Matrícula ruim', 'a b!', 'mecanico')).status, 400);
  r = await chamar('GET', '/api/usuarios', { token: estado.pcm });
  assert.equal(r.json.usuarios.length, 4);
  assert.ok(r.json.usuarios.every((u) => u.pin_hash === undefined && u.pinHash === undefined));

  for (const [mat, chave] of [['carlos', 'carlos'], ['joao', 'joao'], ['paulo', 'paulo']]) {
    const l = await chamar('POST', '/api/auth/login', { corpo: { matricula: mat, pin: '4321' } });
    assert.equal(l.status, 200); estado[chave] = l.json.token;
  }
});

test('quem não é PCM não gerencia equipe nem cria atividades', async () => {
  assert.equal((await chamar('GET', '/api/usuarios', { token: estado.carlos })).status, 403);
  assert.equal((await chamar('POST', '/api/usuarios', { token: estado.carlos, corpo: { nome: 'x', matricula: 'x', funcao: 'pcm', pin: '1234' } })).status, 403);
  assert.equal((await chamar('PATCH', `/api/usuarios/${estado.carlosId}`, { token: estado.carlos, corpo: { funcao: 'pcm' } })).status, 403);
  assert.equal((await chamar('POST', '/api/os', { token: estado.carlos, corpo: {} })).status, 403);
  assert.equal((await chamar('DELETE', '/api/os/1', { token: estado.carlos })).status, 403);
});

test('rotas protegidas exigem login válido', async () => {
  assert.equal((await chamar('GET', '/api/os?semana=2026-01-05')).status, 401);
  assert.equal((await chamar('GET', '/api/os?semana=2026-01-05', { token: 'lixo' })).status, 401);
  const r = await chamar('GET', '/api/nada');
  assert.equal(r.status, 404);
  assert.ok(r.json.erro);
});

test('PCM programa atividades e valida os campos', async () => {
  const base = { titulo: 'Trocar disjuntor do painel 3', equipamento: 'Painel QDF-03', tipo: 'corretiva', prioridade: 'urgente', data: maisDias(0), responsavelId: estado.joaoId };
  let r = await chamar('POST', '/api/os', { token: estado.pcm, corpo: base });
  assert.equal(r.status, 201);
  estado.osJoao = r.json.atividade.id;
  assert.equal(r.json.atividade.responsavelFuncao, 'eletricista');
  assert.equal(r.json.atividade.status, 'pendente');

  r = await chamar('POST', '/api/os', { token: estado.pcm, corpo: { ...base, titulo: 'Lubrificar esteira', equipamento: 'Esteira 7', tipo: 'preventiva', prioridade: 'normal', responsavelId: estado.carlosId } });
  estado.osCarlos = r.json.atividade.id;

  r = await chamar('POST', '/api/os', { token: estado.pcm, corpo: { ...base, titulo: 'Pintar corredor', equipamento: 'Prédio B', tipo: 'melhoria', responsavelId: estado.pauloId } });
  assert.equal(r.status, 201);

  const pcmId = (await chamar('GET', '/api/auth/eu', { token: estado.pcm })).json.usuario.id;
  assert.equal((await chamar('POST', '/api/os', { token: estado.pcm, corpo: { ...base, responsavelId: pcmId } })).status, 400);
  assert.equal((await chamar('POST', '/api/os', { token: estado.pcm, corpo: { ...base, data: '2026-02-31' } })).status, 400);
  assert.equal((await chamar('POST', '/api/os', { token: estado.pcm, corpo: { ...base, titulo: '' } })).status, 400);
  assert.equal((await chamar('POST', '/api/os', { token: estado.pcm, corpo: { ...base, tipo: 'qualquer' } })).status, 400);
  assert.equal((await chamar('POST', '/api/os', { token: estado.pcm, corpo: { ...base, responsavelId: 9999 } })).status, 400);
});

test('cada um só vê as próprias atividades; o PCM vê todas', async () => {
  const semana = maisDias(0);
  let r = await chamar('GET', `/api/os?semana=${semana}`, { token: estado.pcm });
  assert.equal(r.json.atividades.length, 3);
  r = await chamar('GET', `/api/os?semana=${semana}`, { token: estado.joao });
  assert.equal(r.json.atividades.length, 1);
  assert.equal(r.json.atividades[0].titulo, 'Trocar disjuntor do painel 3');
  r = await chamar('GET', `/api/os?semana=${semana}`, { token: estado.carlos });
  assert.equal(r.json.atividades.length, 1);
  assert.equal(r.json.atividades[0].titulo, 'Lubrificar esteira');
  // tentar espiar outro responsável pela URL não funciona para quem não é PCM
  r = await chamar('GET', `/api/os?semana=${semana}&responsavel=${estado.joaoId}`, { token: estado.carlos });
  assert.equal(r.json.atividades.length, 1);
  assert.equal(r.json.atividades[0].responsavelId, estado.carlosId);
  // filtro do PCM
  r = await chamar('GET', `/api/os?semana=${semana}&responsavel=${estado.pauloId}`, { token: estado.pcm });
  assert.equal(r.json.atividades.length, 1);
});

test('finalizar com observação grava histórico; só o responsável (ou PCM) pode', async () => {
  let r = await chamar('POST', `/api/os/${estado.osJoao}/status`, { token: estado.carlos, corpo: { status: 'concluida' } });
  assert.equal(r.status, 404);
  r = await chamar('POST', `/api/os/${estado.osJoao}/status`, { token: estado.joao, corpo: { status: 'pendente' } });
  assert.equal(r.status, 400);
  r = await chamar('POST', `/api/os/${estado.osJoao}/status`, { token: estado.joao, corpo: { status: 'nao_concluida', observacao: 'Faltou peça de fixação.' } });
  assert.equal(r.status, 200);
  assert.equal(r.json.atividade.status, 'nao_concluida');
  assert.equal(r.json.atividade.observacao, 'Faltou peça de fixação.');
  r = await chamar('POST', `/api/os/${estado.osJoao}/status`, { token: estado.joao, corpo: { status: 'concluida', observacao: 'Peça chegou, serviço feito.' } });
  assert.equal(r.json.atividade.historico.length, 2);
  assert.equal(r.json.atividade.historico[0].por, 'João Elétrica');
  assert.equal(r.json.atividade.historico[1].status, 'concluida');
  r = await chamar('POST', `/api/os/${estado.osJoao}/status`, { token: estado.joao, corpo: { status: 'concluida', observacao: 'x'.repeat(1001) } });
  assert.equal(r.status, 400);
  // o PCM também pode registrar
  r = await chamar('POST', `/api/os/${estado.osCarlos}/status`, { token: estado.pcm, corpo: { status: 'concluida' } });
  assert.equal(r.status, 200);
});

test('pendências de semanas anteriores aparecem como atrasadas', async () => {
  const antiga = maisDias(-14);
  let r = await chamar('POST', '/api/os', { token: estado.pcm, corpo: { titulo: 'Revisar bomba', equipamento: 'Bomba BC-102', data: antiga, responsavelId: estado.joaoId } });
  assert.equal(r.status, 201); estado.osAntiga = r.json.atividade.id;
  r = await chamar('POST', '/api/os', { token: estado.pcm, corpo: { titulo: 'Item já feito', equipamento: 'Bomba BC-103', data: antiga, responsavelId: estado.joaoId } });
  await chamar('POST', `/api/os/${r.json.atividade.id}/status`, { token: estado.joao, corpo: { status: 'concluida' } });

  const segundaAtual = (await chamar('GET', `/api/os?semana=${maisDias(0)}`, { token: estado.pcm })).json.semana;
  r = await chamar('GET', `/api/os/atrasadas?antes=${segundaAtual}`, { token: estado.joao });
  assert.equal(r.json.atividades.length, 1);
  assert.equal(r.json.atividades[0].titulo, 'Revisar bomba');
  r = await chamar('GET', `/api/os/atrasadas?antes=${segundaAtual}`, { token: estado.carlos });
  assert.equal(r.json.atividades.length, 0);
  r = await chamar('GET', `/api/os/atrasadas?antes=${segundaAtual}`, { token: estado.pcm });
  assert.equal(r.json.atividades.length, 1);
});

test('PCM edita e exclui atividades', async () => {
  let r = await chamar('PATCH', `/api/os/${estado.osAntiga}`, { token: estado.pcm, corpo: { titulo: 'Revisar bomba (reprogramada)', equipamento: 'Bomba BC-102', data: maisDias(1), responsavelId: estado.pauloId, prioridade: 'alta' } });
  assert.equal(r.status, 200);
  assert.equal(r.json.atividade.responsavelNome, 'Paulo Predial');
  r = await chamar('DELETE', `/api/os/${estado.osAntiga}`, { token: estado.pcm });
  assert.equal(r.status, 200);
  assert.equal((await chamar('DELETE', `/api/os/${estado.osAntiga}`, { token: estado.pcm })).status, 404);
});

test('texto estranho é guardado como texto, sem quebrar nada', async () => {
  const titulo = "'); DROP TABLE os;-- <img src=x onerror=alert(1)>";
  let r = await chamar('POST', '/api/os', { token: estado.pcm, corpo: { titulo, equipamento: 'X', data: maisDias(0), responsavelId: estado.carlosId } });
  assert.equal(r.status, 201);
  r = await chamar('GET', `/api/os?semana=${maisDias(0)}`, { token: estado.pcm });
  assert.ok(r.json.atividades.some((a) => a.titulo === titulo));
});

test('trocar o próprio PIN mantém a sessão nova e derruba a antiga', async () => {
  let r = await chamar('POST', '/api/auth/pin', { token: estado.paulo, corpo: { atual: '9999', novo: '555555' } });
  assert.equal(r.status, 400);
  r = await chamar('POST', '/api/auth/pin', { token: estado.paulo, corpo: { atual: '4321', novo: '555555' } });
  assert.equal(r.status, 200);
  const novoToken = r.json.token;
  assert.equal((await chamar('GET', '/api/auth/eu', { token: estado.paulo })).status, 401);
  assert.equal((await chamar('GET', '/api/auth/eu', { token: novoToken })).status, 200);
  assert.equal((await chamar('POST', '/api/auth/login', { corpo: { matricula: 'paulo', pin: '4321' } })).status, 401);
  assert.equal((await chamar('POST', '/api/auth/login', { corpo: { matricula: 'paulo', pin: '555555' } })).status, 200);
});

test('PCM redefine o PIN de outra pessoa', async () => {
  const r = await chamar('POST', `/api/usuarios/${estado.carlosId}/pin`, { token: estado.pcm, corpo: { pin: '777777' } });
  assert.equal(r.status, 200);
  assert.equal((await chamar('GET', '/api/auth/eu', { token: estado.carlos })).status, 401);
  assert.equal((await chamar('POST', '/api/auth/login', { corpo: { matricula: 'carlos', pin: '4321' } })).status, 401);
  const l = await chamar('POST', '/api/auth/login', { corpo: { matricula: 'carlos', pin: '777777' } });
  assert.equal(l.status, 200);
  estado.carlos = l.json.token;
});

test('desativar derruba o login na hora e impede nova entrada', async () => {
  let r = await chamar('PATCH', `/api/usuarios/${estado.joaoId}`, { token: estado.pcm, corpo: { ativo: false } });
  assert.equal(r.status, 200);
  assert.equal((await chamar('GET', `/api/os?semana=${maisDias(0)}`, { token: estado.joao })).status, 401);
  r = await chamar('POST', '/api/auth/login', { corpo: { matricula: 'joao', pin: '4321' } });
  assert.equal(r.status, 403);
  // não dá para atribuir atividade a quem está inativo
  r = await chamar('POST', '/api/os', { token: estado.pcm, corpo: { titulo: 'x', equipamento: 'y', data: maisDias(0), responsavelId: estado.joaoId } });
  assert.equal(r.status, 400);
  r = await chamar('PATCH', `/api/usuarios/${estado.joaoId}`, { token: estado.pcm, corpo: { ativo: true } });
  assert.equal(r.status, 200);
  assert.equal((await chamar('POST', '/api/auth/login', { corpo: { matricula: 'joao', pin: '4321' } })).status, 200);
});

test('o PCM não se tranca para fora', async () => {
  const eu = (await chamar('GET', '/api/auth/eu', { token: estado.pcm })).json.usuario;
  let r = await chamar('PATCH', `/api/usuarios/${eu.id}`, { token: estado.pcm, corpo: { ativo: false } });
  assert.equal(r.status, 400);
  r = await chamar('PATCH', `/api/usuarios/${eu.id}`, { token: estado.pcm, corpo: { funcao: 'mecanico' } });
  assert.equal(r.status, 400);
});

test('bloqueio temporário depois de muitas tentativas erradas', async () => {
  let ultimo;
  for (let i = 0; i < 9; i++) {
    ultimo = await chamar('POST', '/api/auth/login', { corpo: { matricula: 'paulo', pin: '000000' } });
  }
  assert.equal(ultimo.status, 429);
  const r = await chamar('POST', '/api/auth/login', { corpo: { matricula: 'paulo', pin: '555555' } });
  assert.equal(r.status, 429);
});

test('o servidor entrega as telas e os cabeçalhos de segurança', async () => {
  const r = await fetch(base + '/');
  assert.equal(r.status, 200);
  assert.ok((r.headers.get('content-security-policy') || '').includes("script-src 'self'"));
  assert.equal(r.headers.get('x-powered-by'), null);
});
