'use strict';
// Cópia de segurança do banco: npm run backup
// Cria data/backups/pcm-AAAA-MM-DD-HH-MM-SS.sql (pode ser rodado com o sistema ligado).
// Usa o programa "mysqldump", que vem junto com o MySQL.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { carregarConfig } = require('../src/config');

const config = carregarConfig();
const { host, port, user, password, database } = config.db;

const pasta = path.join(config.dataDir, 'backups');
fs.mkdirSync(pasta, { recursive: true });
const agora = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
const destino = path.join(pasta, `pcm-${agora}.sql`);

const saida = fs.createWriteStream(destino);
// A senha vai por variável de ambiente para não aparecer na linha de comando.
const proc = spawn(
  'mysqldump',
  ['-h', host, '-P', String(port), '-u', user, '--single-transaction', '--default-character-set=utf8mb4', database],
  { env: { ...process.env, MYSQL_PWD: password }, stdio: ['ignore', 'pipe', 'pipe'] }
);

let erros = '';
proc.stderr.on('data', (d) => { erros += d.toString(); });
proc.stdout.pipe(saida);

function falhar(msg) {
  try { fs.unlinkSync(destino); } catch (e) { /* nada a apagar */ }
  console.error('Falha no backup: ' + msg);
  process.exit(1);
}

proc.on('error', (e) => {
  if (e.code === 'ENOENT') {
    falhar('o programa "mysqldump" não foi encontrado. Ele vem com o MySQL: adicione a pasta "bin" do MySQL '
      + '(no Windows, algo como C:\\Program Files\\MySQL\\MySQL Server 8.0\\bin) à variável PATH e tente de novo.');
  }
  falhar(e.message);
});

proc.on('close', (codigo) => {
  if (codigo !== 0) falhar(erros.trim() || `o mysqldump terminou com erro (código ${codigo}).`);
  saida.on('finish', () => console.log('Backup criado: ' + destino));
  saida.end();
});
