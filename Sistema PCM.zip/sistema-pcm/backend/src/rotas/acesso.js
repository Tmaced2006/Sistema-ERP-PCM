'use strict';
const express = require('express');
const rateLimit = require('express-rate-limit');
const V = require('../validacao');
const A = require('../autenticacao');
const { um } = require('../db');

/**
 * Primeiro acesso, login e troca do próprio PIN.
 *   GET  /api/setup            o sistema já tem PCM?
 *   POST /api/setup            cria o primeiro PCM (só funciona uma vez)
 *   POST /api/auth/login       entra com matrícula e PIN
 *   GET  /api/auth/eu          dados de quem está logado
 *   POST /api/auth/pin         troca o próprio PIN
 */
module.exports = function rotasAcesso(db, config, exigirLogin) {
  const r = express.Router();
  const ass = V.assincrono;

  const limite = config.limitarTentativas
    ? rateLimit({
        windowMs: 15 * 60 * 1000,
        limit: 30,
        standardHeaders: true,
        legacyHeaders: false,
        message: { erro: 'Muitas tentativas. Aguarde alguns minutos e tente de novo.' },
      })
    : (_req, _res, next) => next();

  // Bloqueio por matrícula: depois de 8 erros seguidos, 10 minutos de espera.
  const falhas = new Map();
  const MAX_FALHAS = 8, ESPERA_MS = 10 * 60 * 1000;
  function bloqueado(mat) {
    const f = falhas.get(mat);
    if (!f) return false;
    if (f.ate && f.ate > Date.now()) return true;
    if (f.ate && f.ate <= Date.now()) falhas.delete(mat);
    return false;
  }
  function registrarFalha(mat) {
    const f = falhas.get(mat) || { n: 0, ate: 0 };
    f.n += 1;
    if (f.n >= MAX_FALHAS) { f.ate = Date.now() + ESPERA_MS; f.n = 0; }
    falhas.set(mat, f);
  }

  const INSERIR =
    'INSERT INTO usuarios (matricula, nome, funcao, pin_hash, ativo, token_versao, criado_em) VALUES (?,?,?,?,1,0,?)';

  r.get('/setup', ass(async (_req, res) => {
    const c = await um(db, 'SELECT COUNT(*) AS n FROM usuarios');
    res.json({ configurado: Number(c.n) > 0 });
  }));

  r.post('/setup', limite, ass(async (req, res) => {
    const nome = V.texto(req.body.nome, { campo: 'o nome', obrigatorio: true, max: 60 });
    const mat = V.matricula(req.body.matricula);
    const hash = A.gerarHash(V.pin(req.body.pin));

    // Uma trava garante que dois pedidos ao mesmo tempo não criem dois "primeiros" PCMs.
    const cx = await db.getConnection();
    let u;
    try {
      const [[trava]] = await cx.query("SELECT GET_LOCK('pcm_setup', 10) AS ok");
      if (Number(trava.ok) !== 1) throw new V.ErroHttp(503, 'Servidor ocupado. Tente de novo em instantes.');
      try {
        const [[c]] = await cx.query('SELECT COUNT(*) AS n FROM usuarios');
        if (Number(c.n) > 0) throw new V.ErroHttp(409, 'O sistema já foi configurado. Entre com a sua matrícula.');
        const [info] = await cx.execute(INSERIR, [mat, nome, 'pcm', hash, Date.now()]);
        const [linhas] = await cx.execute('SELECT * FROM usuarios WHERE id = ?', [info.insertId]);
        u = linhas[0];
      } finally {
        await cx.query("SELECT RELEASE_LOCK('pcm_setup')");
      }
    } finally {
      cx.release();
    }
    res.status(201).json({ token: A.criarToken(config, u), usuario: A.usuarioPublico(u) });
  }));

  r.post('/auth/login', limite, ass(async (req, res) => {
    const mat = String(req.body.matricula || '').trim().toLowerCase();
    const pin = String(req.body.pin || '');
    if (!mat || !pin) throw new V.ErroHttp(400, 'Informe a matrícula e o PIN.');
    if (bloqueado(mat)) throw new V.ErroHttp(429, 'Acesso bloqueado por alguns minutos após várias tentativas erradas.');
    const u = await um(db, 'SELECT * FROM usuarios WHERE matricula = ?', [mat]);
    const certo = A.conferirPin(pin, u && u.pin_hash);
    if (!u || !certo) {
      registrarFalha(mat);
      throw new V.ErroHttp(401, 'Matrícula ou PIN incorretos.');
    }
    if (!u.ativo) throw new V.ErroHttp(403, 'Seu acesso foi desativado. Fale com o PCM.');
    falhas.delete(mat);
    res.json({ token: A.criarToken(config, u), usuario: A.usuarioPublico(u) });
  }));

  r.get('/auth/eu', exigirLogin, (req, res) => {
    res.json({ usuario: A.usuarioPublico(req.usuario) });
  });

  r.post('/auth/pin', exigirLogin, limite, ass(async (req, res) => {
    const u = await um(db, 'SELECT * FROM usuarios WHERE id = ?', [req.usuario.id]);
    if (!A.conferirPin(String(req.body.atual || ''), u.pin_hash)) {
      throw new V.ErroHttp(400, 'O PIN atual não confere.');
    }
    const novo = V.pin(req.body.novo);
    await db.execute('UPDATE usuarios SET pin_hash = ?, token_versao = token_versao + 1 WHERE id = ?', [
      A.gerarHash(novo), u.id,
    ]);
    const atualizado = await um(db, 'SELECT * FROM usuarios WHERE id = ?', [u.id]);
    // Devolve um login novo, para a pessoa continuar logada neste aparelho.
    res.json({ token: A.criarToken(config, atualizado) });
  }));

  return r;
};
