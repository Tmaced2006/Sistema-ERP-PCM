'use strict';
const mysql = require('mysql2/promise');

// As tabelas são criadas sozinhas na primeira vez que o sistema liga (se ainda não existirem).
// O mesmo esquema está em banco/criar-banco.sql, caso você prefira criar à mão.
const TABELAS = [
  `CREATE TABLE IF NOT EXISTS usuarios (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    matricula     VARCHAR(50)  NOT NULL UNIQUE,
    nome          VARCHAR(60)  NOT NULL,
    funcao        ENUM('pcm','mecanico','eletricista','predial') NOT NULL,
    pin_hash      VARCHAR(100) NOT NULL,
    ativo         TINYINT(1)   NOT NULL DEFAULT 1,
    token_versao  INT          NOT NULL DEFAULT 0,
    criado_em     BIGINT       NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS os (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    numero          VARCHAR(30)   NOT NULL DEFAULT '',
    titulo          VARCHAR(120)  NOT NULL,
    equipamento     VARCHAR(80)   NOT NULL,
    tipo            ENUM('preventiva','corretiva','preditiva','inspecao','melhoria') NOT NULL DEFAULT 'preventiva',
    prioridade      ENUM('normal','alta','urgente') NOT NULL DEFAULT 'normal',
    \`data\`          CHAR(10)      NOT NULL,
    semana          CHAR(10)      NOT NULL,
    responsavel_id  INT UNSIGNED  NOT NULL,
    descricao       VARCHAR(1500) NOT NULL DEFAULT '',
    status          ENUM('pendente','concluida','nao_concluida') NOT NULL DEFAULT 'pendente',
    observacao      VARCHAR(1000) NOT NULL DEFAULT '',
    atualizado_por  INT UNSIGNED  NULL,
    atualizado_em   BIGINT        NULL,
    criado_por      INT UNSIGNED  NOT NULL,
    criado_em       BIGINT        NOT NULL,
    FOREIGN KEY (responsavel_id) REFERENCES usuarios(id),
    FOREIGN KEY (atualizado_por) REFERENCES usuarios(id),
    FOREIGN KEY (criado_por)     REFERENCES usuarios(id),
    INDEX idx_os_semana (semana),
    INDEX idx_os_resp_status (responsavel_id, status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

  `CREATE TABLE IF NOT EXISTS os_historico (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    os_id      INT UNSIGNED  NOT NULL,
    em         BIGINT        NOT NULL,
    por_id     INT UNSIGNED  NOT NULL,
    por_nome   VARCHAR(60)   NOT NULL,
    status     VARCHAR(20)   NOT NULL,
    observacao VARCHAR(1000) NOT NULL DEFAULT '',
    FOREIGN KEY (os_id)  REFERENCES os(id) ON DELETE CASCADE,
    FOREIGN KEY (por_id) REFERENCES usuarios(id),
    INDEX idx_hist_os (os_id, em)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
];

/** Conecta ao MySQL (pool de conexões) e garante que as tabelas existem. */
async function abrirBanco(cfg) {
  const pool = mysql.createPool({
    host: cfg.host,
    port: cfg.port,
    user: cfg.user,
    password: cfg.password,
    database: cfg.database,
    charset: 'utf8mb4',
    waitForConnections: true,
    connectionLimit: 10,
    supportBigNumbers: true,   // números grandes só viram texto se passarem de 2^53
    bigNumberStrings: false,
  });
  try {
    await pool.query('SELECT 1');
    for (const sql of TABELAS) await pool.query(sql);
  } catch (e) {
    await pool.end().catch(() => {});
    throw e;
  }
  return pool;
}

/** Devolve a primeira linha do resultado (ou undefined). */
async function um(db, sql, params = []) {
  const [linhas] = await db.execute(sql, params);
  return linhas[0];
}

/** Devolve todas as linhas do resultado. */
async function todos(db, sql, params = []) {
  const [linhas] = await db.execute(sql, params);
  return linhas;
}

/** Roda `fn(conexao)` dentro de uma transação: tudo é gravado junto ou nada é. */
async function comTransacao(db, fn) {
  const cx = await db.getConnection();
  try {
    await cx.beginTransaction();
    const resultado = await fn(cx);
    await cx.commit();
    return resultado;
  } catch (e) {
    try { await cx.rollback(); } catch (_) { /* conexão já caiu */ }
    throw e;
  } finally {
    cx.release();
  }
}

module.exports = { abrirBanco, um, todos, comTransacao };
