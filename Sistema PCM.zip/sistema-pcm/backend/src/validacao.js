'use strict';

const FUNCOES = ['pcm', 'mecanico', 'eletricista', 'predial'];
const TIPOS = ['preventiva', 'corretiva', 'preditiva', 'inspecao', 'melhoria'];
const PRIORIDADES = ['normal', 'alta', 'urgente'];
const STATUS = ['pendente', 'concluida', 'nao_concluida'];

class ErroHttp extends Error {
  constructor(status, mensagem) {
    super(mensagem);
    this.status = status;
  }
}

function texto(valor, { campo, min = 0, max, obrigatorio = false }) {
  const v = valor == null ? '' : String(valor).trim();
  if (obrigatorio && !v) throw new ErroHttp(400, `Informe ${campo}.`);
  if (v.length < min) throw new ErroHttp(400, `${campo} está curto demais.`);
  if (v.length > max) throw new ErroHttp(400, `${campo} passou de ${max} caracteres.`);
  return v;
}

function matricula(valor) {
  const v = String(valor == null ? '' : valor).trim().toLowerCase();
  if (!/^[a-z0-9_.-]{1,40}$/.test(v)) {
    throw new ErroHttp(400, 'Matrícula: use só letras, números, ponto, hífen ou sublinhado.');
  }
  return v;
}

function pin(valor) {
  const v = String(valor == null ? '' : valor);
  if (!/^\d{4,8}$/.test(v)) throw new ErroHttp(400, 'O PIN precisa ter de 4 a 8 números.');
  return v;
}

function opcao(valor, lista, campo) {
  if (!lista.includes(valor)) throw new ErroHttp(400, `${campo} inválido.`);
  return valor;
}

function inteiro(valor, campo) {
  const n = Number(valor);
  if (!Number.isInteger(n) || n <= 0) throw new ErroHttp(400, `${campo} inválido.`);
  return n;
}

/** Aceita "AAAA-MM-DD" de um dia que existe no calendário. */
function dataIso(valor, campo = 'Data') {
  const v = String(valor == null ? '' : valor);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
  if (!m) throw new ErroHttp(400, `${campo} inválida.`);
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  if (d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) {
    throw new ErroHttp(400, `${campo} inválida.`);
  }
  return v;
}

/** Segunda-feira da semana da data informada, no formato AAAA-MM-DD. */
function segundaDaSemana(iso) {
  const [a, m, dia] = iso.split('-').map(Number);
  const d = new Date(Date.UTC(a, m - 1, dia));
  d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
  return d.toISOString().slice(0, 10);
}

/**
 * O Express 4 não captura sozinho os erros de funções assíncronas.
 * Isto repassa qualquer erro para o tratador de erros do servidor.
 */
function assincrono(fn) {
  return (req, res, next) => { Promise.resolve(fn(req, res, next)).catch(next); };
}

module.exports = {
  FUNCOES, TIPOS, PRIORIDADES, STATUS,
  ErroHttp, texto, matricula, pin, opcao, inteiro, dataIso, segundaDaSemana, assincrono,
};
