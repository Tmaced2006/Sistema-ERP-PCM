/* Telas do sistema: entrada, semana, atividade, equipe. */
(function () {
  'use strict';
  var U = window.PCM.util, api = window.PCM.api, h = U.h;
  var $app = document.getElementById('app');

  var S = {
    tela: 'carregando', erro: '',
    user: null, users: [],
    ws: U.weekStart(new Date()),
    os: [], late: [], loaded: false, erroCarga: '', sig: '',
    fStatus: 'todas', fMec: 'todos', view: 'semana',
    ultimaTela: '', aviso: '', timer: null
  };

  function ehPcm() { return !!S.user && S.user.funcao === 'pcm'; }
  function responsaveis() {
    return S.users.filter(function (u) { return u.funcao !== 'pcm' && u.ativo; });
  }

  /* ================= carregamento ================= */
  async function carregar() {
    var u = S.user;
    if (!u) return;
    var ws = U.ymd(S.ws);
    try {
      var r = await Promise.all([
        api.get('/os?semana=' + ws),
        api.get('/os/atrasadas?antes=' + ws),
        u.funcao === 'pcm' ? api.get('/usuarios') : null
      ]);
      if (S.user !== u || U.ymd(S.ws) !== ws) return; // mudou de semana ou saiu enquanto carregava
      var sig = JSON.stringify(r);
      S.os = r[0].atividades;
      S.late = r[1].atividades;
      if (r[2]) S.users = r[2].usuarios;
      var primeira = !S.loaded;
      S.loaded = true; S.erroCarga = '';
      if (primeira || sig !== S.sig) { S.sig = sig; render(); }
    } catch (e) {
      if (e.status === 401) return;
      if (!S.loaded) { S.erroCarga = e.message; render(); }
    }
  }
  function recarregar() { S.sig = ''; return carregar(); }

  function iniciarAtualizacao() {
    pararAtualizacao();
    S.timer = setInterval(function () { if (!document.hidden) carregar(); }, 30000);
  }
  function pararAtualizacao() { if (S.timer) { clearInterval(S.timer); S.timer = null; } }
  document.addEventListener('visibilitychange', function () { if (!document.hidden && S.user) carregar(); });

  function entrou(usuario) {
    S.user = usuario; S.users = []; S.os = []; S.late = []; S.loaded = false; S.erroCarga = ''; S.sig = '';
    S.view = 'semana'; S.fStatus = 'todas'; S.fMec = 'todos'; S.ws = U.weekStart(new Date()); S.aviso = '';
    S.tela = 'app';
    render();
    carregar();
    iniciarAtualizacao();
  }
  function saiu(aviso) {
    pararAtualizacao(); U.closeSheet();
    S.user = null; S.aviso = aviso || ''; S.tela = 'login';
    S.ultimaTela = ''; render();
  }
  api.aoExpirar(function (msg) { saiu(msg); });

  function sair() { api.guardarToken(null); saiu(''); }

  function trocarSemana(d) {
    S.ws = U.weekStart(d); S.os = []; S.late = []; S.loaded = false; S.sig = '';
    render(); carregar();
  }

  /* ================= telas ================= */
  function render() {
    var t = S.tela;
    if ((t === 'login' || t === 'setup') && S.ultimaTela === t) return; // não apaga o que a pessoa digita
    S.ultimaTela = t;
    $app.replaceChildren();
    if (t === 'carregando') $app.append(h('p', { class: 'loading' }, 'Carregando o sistema…'));
    else if (t === 'erro') $app.append(telaErro());
    else if (t === 'setup') $app.append(telaSetup());
    else if (t === 'login') $app.append(telaLogin());
    else $app.append(telaApp());
  }

  function telaErro() {
    return h('div', { class: 'empty' },
      h('h3', {}, 'Não foi possível abrir o sistema'),
      h('p', {}, S.erro || 'Sem conexão com o servidor.'),
      h('button', { class: 'btn', onclick: iniciar }, 'Tentar de novo'));
  }

  function telaSetup() {
    var nome = U.inp('s-nome', { type: 'text', maxlength: '60', autocomplete: 'off' });
    var mat = U.inp('s-mat', { type: 'text', maxlength: '40', autocomplete: 'off', autocapitalize: 'off' });
    var pin = U.inp('s-pin', { type: 'password', inputmode: 'numeric', maxlength: '8', autocomplete: 'new-password' });
    var err = h('p', { class: 'err', role: 'alert' });
    var btn = h('button', { type: 'submit', class: 'btn block' }, 'Criar acesso do PCM');
    var form = h('form', { class: 'card', onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (!nome.value.trim()) return (err.textContent = 'Informe o nome.');
      if (!mat.value.trim()) return (err.textContent = 'Informe a matrícula.');
      if (!/^\d{4,8}$/.test(pin.value)) return (err.textContent = 'O PIN precisa ter de 4 a 8 números.');
      btn.disabled = true;
      try {
        var r = await api.post('/setup', { nome: nome.value.trim(), matricula: mat.value.trim(), pin: pin.value });
        api.guardarToken(r.token);
        entrou(r.usuario);
      } catch (x) {
        err.textContent = x.message; btn.disabled = false;
        if (x.status === 409) { S.tela = 'login'; S.ultimaTela = ''; render(); }
      }
    } },
      U.field('Seu nome', nome),
      U.field('Sua matrícula', mat, 'É o que você digita para entrar.'),
      U.field('PIN de acesso', pin, 'De 4 a 8 números. Anote em lugar seguro.'),
      btn, err);
    return h('div', { class: 'auth' },
      h('div', { class: 'eyebrow' }, 'Primeiro acesso'),
      h('h2', {}, 'Configurar a programação'),
      h('p', {}, 'Crie o seu acesso como PCM. Em seguida, cadastre a equipe e programe as atividades da semana.'),
      form);
  }

  function telaLogin() {
    var mat = U.inp('l-mat', { type: 'text', maxlength: '40', autocomplete: 'username', autocapitalize: 'off' });
    var pin = U.inp('l-pin', { type: 'password', inputmode: 'numeric', maxlength: '8', autocomplete: 'current-password' });
    var err = h('p', { class: 'err', role: 'alert' }, S.aviso);
    var btn = h('button', { type: 'submit', class: 'btn block' }, 'Entrar');
    var form = h('form', { class: 'card', onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (!mat.value.trim() || !pin.value) { err.textContent = 'Informe a matrícula e o PIN.'; return; }
      btn.disabled = true;
      try {
        var r = await api.post('/auth/login', { matricula: mat.value.trim(), pin: pin.value });
        api.guardarToken(r.token);
        entrou(r.usuario);
      } catch (x) { err.textContent = x.message; pin.value = ''; btn.disabled = false; }
    } },
      U.field('Matrícula', mat), U.field('PIN', pin), btn, err);
    return h('div', { class: 'auth' },
      h('div', { class: 'eyebrow' }, 'PCM · Manutenção'),
      h('h2', {}, 'Programação semanal'),
      h('p', {}, 'Entre com a sua matrícula para ver as atividades da semana.'),
      form);
  }

  function telaApp() {
    var m = S.user, pcm = ehPcm();
    var root = h('div', {});
    root.append(h('header', { class: 'top' },
      h('div', { class: 'brand' }, h('div', { class: 'eyebrow' }, 'PCM · Manutenção'), h('h1', {}, 'Programação semanal')),
      h('div', { class: 'who' },
        h('div', { class: 'who-t' }, h('div', { class: 'who-n' }, m.nome), h('div', { class: 'who-r' }, U.funcLabel(m.funcao))),
        h('button', { type: 'button', class: 'btn ghost sm', onclick: abrirMeuPin }, 'Meu PIN'),
        h('button', { type: 'button', class: 'btn ghost sm', onclick: sair }, 'Sair'))));
    if (pcm) {
      root.append(h('div', { class: 'tabs', role: 'tablist' },
        h('button', { class: 'tab', role: 'tab', 'aria-selected': String(S.view === 'semana'), onclick: function () { S.view = 'semana'; render(); } }, 'Semana'),
        h('button', { class: 'tab', role: 'tab', 'aria-selected': String(S.view === 'equipe'), onclick: function () { S.view = 'equipe'; render(); } }, 'Equipe')));
    }
    root.append(pcm && S.view === 'equipe' ? viewEquipe() : viewSemana());
    return root;
  }

  /* ---------- semana ---------- */
  function filtrar(lista) {
    return lista.filter(function (o) {
      if (S.fStatus === 'todas') return true;
      if (S.fStatus === 'obs') return !!o.observacao;
      return o.status === S.fStatus;
    });
  }
  var ORD = { urgente: 0, alta: 1, normal: 2 };
  function ordenar(a, b) {
    var pa = ORD[a.prioridade] != null ? ORD[a.prioridade] : 2, pb = ORD[b.prioridade] != null ? ORD[b.prioridade] : 2;
    return pa - pb || String(a.titulo).localeCompare(String(b.titulo), 'pt-BR');
  }

  function viewSemana() {
    var pcm = ehPcm(), box = h('div', {});
    var hoje = U.ymd(new Date()), fim = U.addDays(S.ws, 6);
    var list = S.os, late = S.late;
    if (pcm && S.fMec !== 'todos') {
      list = list.filter(function (o) { return String(o.responsavelId) === S.fMec; });
      late = late.filter(function (o) { return String(o.responsavelId) === S.fMec; });
    }

    var bar = h('div', { class: 'weekbar' },
      h('div', { class: 'week-t' },
        h('h2', {}, 'Semana ' + U.isoWeek(S.ws)),
        h('p', {}, U.shortDate(S.ws) + ' a ' + U.shortDate(fim) + ' de ' + fim.getFullYear())),
      h('div', { class: 'week-nav' },
        h('button', { class: 'icon-btn', 'aria-label': 'Semana anterior', html: U.ICON.left, onclick: function () { trocarSemana(U.addDays(S.ws, -7)); } }),
        h('button', { class: 'btn ghost', onclick: function () { trocarSemana(new Date()); } }, 'Hoje'),
        h('button', { class: 'icon-btn', 'aria-label': 'Próxima semana', html: U.ICON.right, onclick: function () { trocarSemana(U.addDays(S.ws, 7)); } })));
    if (pcm) bar.append(h('button', { class: 'btn', onclick: function () { abrirFormAtividade(null); } }, '+ Nova atividade'));
    box.append(bar);

    var c = { total: list.length, concluida: 0, nao_concluida: 0, pendente: 0, obs: 0 };
    list.forEach(function (o) { c[o.status] = (c[o.status] || 0) + 1; if (o.observacao) c.obs++; });
    var pct = function (n) { return c.total ? (n / c.total * 100) : 0; };
    var sum = h('section', { class: 'summary', 'aria-label': 'Resumo da semana' },
      h('div', { class: 'sum-head' },
        h('div', { class: 'sum-big' }, c.concluida + ' de ' + c.total, h('small', {}, c.total === 1 ? 'atividade finalizada' : 'atividades finalizadas')),
        late.length ? h('span', { class: 'pill urgente' }, late.length + (late.length === 1 ? ' pendência anterior' : ' pendências anteriores')) : null),
      h('div', { class: 'bar', role: 'img', 'aria-label': c.concluida + ' finalizadas, ' + c.nao_concluida + ' não finalizadas, ' + c.pendente + ' pendentes' },
        h('span', { class: 'b-ok', style: 'width:' + pct(c.concluida) + '%' }),
        h('span', { class: 'b-no', style: 'width:' + pct(c.nao_concluida) + '%' })),
      h('div', { class: 'legend' },
        h('span', { class: 'lg' }, h('i', { class: 'dot ok' }), h('b', {}, c.concluida), 'finalizadas'),
        h('span', { class: 'lg' }, h('i', { class: 'dot no' }), h('b', {}, c.nao_concluida), 'não finalizadas'),
        h('span', { class: 'lg' }, h('i', { class: 'dot' }), h('b', {}, c.pendente), 'pendentes')));
    if (pcm && S.fMec === 'todos' && c.total) {
      var per = {}, ordem = [];
      list.forEach(function (o) {
        var p = per[o.responsavelId];
        if (!p) { p = per[o.responsavelId] = { nome: o.responsavelNome, t: 0, d: 0 }; ordem.push(o.responsavelId); }
        p.t++; if (o.status === 'concluida') p.d++;
      });
      var pm = h('div', { class: 'per-mec' });
      ordem.sort(function (a, b) { return per[a].nome.localeCompare(per[b].nome, 'pt-BR'); }).forEach(function (id) {
        pm.append(h('div', { class: 'pm' },
          h('span', { class: 'pm-n' }, per[id].nome),
          h('div', { class: 'bar' }, h('span', { class: 'b-ok', style: 'width:' + (per[id].d / per[id].t * 100) + '%' })),
          h('span', { class: 'pm-c' }, per[id].d + '/' + per[id].t)));
      });
      sum.append(pm);
    }
    box.append(sum);

    var counts = { todas: c.total, pendente: c.pendente, concluida: c.concluida, nao_concluida: c.nao_concluida, obs: c.obs };
    var fl = h('div', { class: 'filters' });
    if (pcm) {
      var ms = [['todos', 'Todos os responsáveis']].concat(responsaveis().map(function (u) { return [String(u.id), u.nome + ' · ' + U.funcLabel(u.funcao)]; }));
      var sm = U.sel('f-mec', ms, S.fMec);
      sm.setAttribute('aria-label', 'Filtrar por responsável');
      sm.addEventListener('change', function () { S.fMec = sm.value; render(); });
      fl.append(sm);
    }
    U.FILTROS.forEach(function (f) {
      fl.append(h('button', { class: 'chip', 'aria-pressed': String(S.fStatus === f[0]), onclick: function () { S.fStatus = f[0]; render(); } }, f[1], h('b', {}, counts[f[0]])));
    });
    box.append(fl);

    var atrasadas = filtrar(late).sort(function (a, b) { return a.data < b.data ? -1 : a.data > b.data ? 1 : ordenar(a, b); });
    if (atrasadas.length) {
      box.append(h('div', { class: 'day' }, h('h3', {}, 'Pendências de semanas anteriores'), h('span', { class: 'tag late' }, 'Atrasadas')));
      box.append(h('div', { class: 'list' }, atrasadas.map(function (o) { return linha(o, pcm, true); })));
    }

    var mostradas = filtrar(list);
    if (S.erroCarga && !S.loaded) {
      box.append(h('div', { class: 'empty' }, h('h3', {}, 'Não foi possível carregar'), h('p', {}, S.erroCarga),
        h('button', { class: 'btn', onclick: function () { S.erroCarga = ''; render(); carregar(); } }, 'Tentar de novo')));
    } else if (!S.loaded) {
      box.append(h('p', { class: 'loading' }, 'Carregando atividades…'));
    } else if (!mostradas.length && !atrasadas.length) {
      box.append(c.total
        ? h('div', { class: 'empty' }, h('h3', {}, 'Nada neste filtro'), h('p', {}, 'Nenhuma atividade desta semana combina com o filtro escolhido.'))
        : h('div', { class: 'empty' }, h('h3', {}, pcm ? 'Semana sem atividades' : 'Nenhuma atividade para você'),
            h('p', {}, pcm ? 'Use “Nova atividade” para programar a semana e escolher o responsável.' : 'Quando o PCM programar atividades para você nesta semana, elas aparecem aqui.')));
    } else {
      var dias = {};
      mostradas.forEach(function (o) { (dias[o.data] || (dias[o.data] = [])).push(o); });
      Object.keys(dias).sort().forEach(function (d) {
        box.append(h('div', { class: 'day' }, h('h3', {}, U.dayLabel(d)), d === hoje ? h('span', { class: 'tag' }, 'Hoje') : null));
        box.append(h('div', { class: 'list' }, dias[d].sort(ordenar).map(function (o) { return linha(o, pcm, false); })));
      });
    }
    return box;
  }

  function linha(o, pcm, mostrarData) {
    var d = U.parseYmd(o.data);
    var meta = h('div', { class: 'it-m' },
      o.numero ? h('span', { class: 'mono' }, 'OS ' + o.numero) : null,
      h('span', {}, o.equipamento),
      o.tipo ? h('span', {}, U.tipoLabel(o.tipo)) : null,
      mostrarData ? h('span', {}, 'prevista ' + U.pad(d.getDate()) + '/' + U.pad(d.getMonth() + 1)) : null,
      pcm ? h('span', {}, o.responsavelNome) : null);
    var dir = h('div', { class: 'it-r' },
      o.prioridade && o.prioridade !== 'normal' ? h('span', { class: 'pill ' + o.prioridade }, o.prioridade === 'urgente' ? 'Urgente' : 'Alta') : null,
      o.status !== 'pendente' ? h('span', { class: 'pill ' + (o.status === 'concluida' ? 'ok' : 'no') }, U.STATUS_LABEL[o.status]) : null,
      o.observacao ? h('span', { class: 'note-flag' }, h('span', { html: U.ICON.note }), 'Obs.') : null);
    return h('button', { class: 'item', type: 'button', onclick: function () { abrirDetalhe(o.id); } },
      h('span', { class: 'st st-' + o.status, html: U.ICON[o.status] || U.ICON.pendente }),
      h('div', {}, h('div', { class: 'it-t' }, o.titulo), meta),
      dir);
  }

  /* ---------- detalhe da atividade ---------- */
  function achar(id) {
    return S.os.filter(function (o) { return o.id === id; })[0] || S.late.filter(function (o) { return o.id === id; })[0] || null;
  }

  function abrirDetalhe(id) {
    var o = achar(id); if (!o || !S.user) return;
    var pcm = ehPcm();
    var escolha = o.status === 'pendente' ? null : o.status;
    var kv = h('dl', { class: 'kv' },
      h('dt', {}, 'Equipamento'), h('dd', {}, o.equipamento),
      o.tipo ? h('dt', {}, 'Tipo') : null, o.tipo ? h('dd', {}, U.tipoLabel(o.tipo)) : null,
      h('dt', {}, 'Data'), h('dd', {}, U.dayLabel(o.data)),
      h('dt', {}, 'Responsável'), h('dd', {}, o.responsavelNome + ' · ' + U.funcLabel(o.responsavelFuncao)),
      h('dt', {}, 'Prioridade'), h('dd', {}, U.prioLabel(o.prioridade)));
    var btnOk = h('button', { type: 'button', class: 'choice ok', 'aria-pressed': 'false' }, h('span', { html: U.ICON.concluida }), 'Finalizada');
    var btnNo = h('button', { type: 'button', class: 'choice no', 'aria-pressed': 'false' }, h('span', { html: U.ICON.nao_concluida }), 'Ainda não finalizada');
    var ta = h('textarea', { id: 'd-obs', class: 'in', maxlength: '1000', placeholder: 'Ex.: vazamento na vedação, peça desgastada, faltou material…', value: o.observacao || '' });
    var salvar = h('button', { type: 'button', class: 'btn block' }, 'Salvar');
    function marcar(v) {
      escolha = v;
      btnOk.setAttribute('aria-pressed', String(v === 'concluida'));
      btnNo.setAttribute('aria-pressed', String(v === 'nao_concluida'));
      salvar.disabled = !v;
    }
    btnOk.addEventListener('click', function () { marcar('concluida'); });
    btnNo.addEventListener('click', function () { marcar('nao_concluida'); });
    marcar(escolha);
    salvar.addEventListener('click', async function () {
      if (!escolha) return;
      salvar.disabled = true;
      try {
        await api.post('/os/' + o.id + '/status', { status: escolha, observacao: ta.value.trim() });
        U.closeSheet(); U.toast('Atividade atualizada.'); recarregar();
      } catch (e) { U.toast(e.message, true); salvar.disabled = false; }
    });
    var corpo = h('div', {},
      o.numero ? h('p', { class: 'mono muted', style: 'margin:-8px 0 12px' }, 'OS ' + o.numero) : null,
      kv,
      o.descricao ? h('p', { class: 'desc' }, o.descricao) : null,
      h('div', { class: 'lbl' }, 'Situação da atividade'),
      h('div', { class: 'choices' }, btnOk, btnNo),
      U.field('Observação', ta, 'Registre o que encontrou ou o motivo de não ter finalizado. É opcional.'),
      salvar);
    var hist = (o.historico || []).slice().reverse();
    if (hist.length) {
      corpo.append(h('ul', { class: 'hist', 'aria-label': 'Histórico' }, hist.map(function (x) {
        return h('li', {}, h('b', {}, U.stamp(x.em) + ' · ' + x.por), ' marcou ', U.STATUS_LABEL[x.status].toLowerCase(), x.observacao ? (' — ' + x.observacao) : '');
      })));
    }
    if (pcm) {
      var acoes = h('div', { class: 'actions' });
      var normal = function () {
        acoes.replaceChildren(
          h('button', { type: 'button', class: 'btn ghost grow', onclick: function () { U.closeSheet(); abrirFormAtividade(o); } }, 'Editar atividade'),
          h('button', { type: 'button', class: 'btn danger grow', onclick: confirmar }, 'Excluir'));
      };
      var confirmar = function () {
        acoes.replaceChildren(
          h('button', { type: 'button', class: 'btn danger solid grow', onclick: async function () {
            try { await api.del('/os/' + o.id); U.closeSheet(); U.toast('Atividade excluída.'); recarregar(); }
            catch (e) { U.toast(e.message, true); }
          } }, 'Confirmar exclusão'),
          h('button', { type: 'button', class: 'btn ghost grow', onclick: normal }, 'Cancelar'));
      };
      normal(); corpo.append(acoes);
    }
    U.openSheet(o.titulo, corpo);
  }

  /* ---------- formulário de atividade (PCM) ---------- */
  function abrirFormAtividade(o) {
    var edicao = !!o, pessoas = responsaveis();
    if (!pessoas.length) {
      U.openSheet('Nova atividade', h('div', {},
        h('p', {}, 'Ainda não há mecânicos, eletricistas ou pessoal de predial cadastrados. Cadastre a equipe antes de programar atividades.'),
        h('button', { class: 'btn block', onclick: function () { U.closeSheet(); S.view = 'equipe'; render(); } }, 'Ir para Equipe')));
      return;
    }
    var hojeNaSemana = U.ymd(new Date()) >= U.ymd(S.ws) && U.ymd(new Date()) <= U.ymd(U.addDays(S.ws, 6));
    var num = U.inp('f-num', { type: 'text', maxlength: '30', value: o ? o.numero || '' : '', placeholder: 'Número da OS no sistema da empresa' });
    var tit = U.inp('f-tit', { type: 'text', maxlength: '120', value: o ? o.titulo : '', placeholder: 'Ex.: Trocar rolamento do motor' });
    var eq = U.inp('f-eq', { type: 'text', maxlength: '80', value: o ? o.equipamento : '', placeholder: 'Ex.: Bomba BC-102' });
    var tipo = U.sel('f-tipo', U.TIPOS, o && o.tipo ? o.tipo : 'preventiva');
    var pri = U.sel('f-pri', U.PRIO, o && o.prioridade ? o.prioridade : 'normal');
    var dt = U.inp('f-data', { type: 'date', value: o ? o.data : (hojeNaSemana ? U.ymd(new Date()) : U.ymd(S.ws)) });
    var opts = pessoas.map(function (u) { return [String(u.id), u.nome + ' · ' + U.funcLabel(u.funcao)]; });
    if (o && !pessoas.some(function (u) { return u.id === o.responsavelId; })) opts.unshift([String(o.responsavelId), o.responsavelNome + ' (inativo)']);
    var resp = U.sel('f-resp', opts, o ? String(o.responsavelId) : opts[0][0]);
    var desc = h('textarea', { id: 'f-desc', class: 'in', maxlength: '1500', placeholder: 'O que precisa ser feito, ferramentas, cuidados de segurança…', value: o ? o.descricao || '' : '' });
    var err = h('p', { class: 'err', role: 'alert' });
    var btn = h('button', { type: 'submit', class: 'btn block' }, edicao ? 'Salvar alterações' : 'Programar atividade');
    var form = h('form', { onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (!tit.value.trim()) return (err.textContent = 'Informe o título da atividade.');
      if (!eq.value.trim()) return (err.textContent = 'Informe o equipamento.');
      if (!dt.value) return (err.textContent = 'Escolha a data.');
      var dados = { numero: num.value.trim(), titulo: tit.value.trim(), equipamento: eq.value.trim(), tipo: tipo.value,
        prioridade: pri.value, data: dt.value, responsavelId: Number(resp.value), descricao: desc.value.trim() };
      btn.disabled = true;
      try {
        if (edicao) await api.patch('/os/' + o.id, dados); else await api.post('/os', dados);
        var semana = U.ymd(U.weekStart(U.parseYmd(dados.data)));
        U.closeSheet(); U.toast(edicao ? 'Atividade atualizada.' : 'Atividade programada.');
        if (semana !== U.ymd(S.ws)) trocarSemana(U.parseYmd(dados.data)); else recarregar();
      } catch (x) { err.textContent = x.message; btn.disabled = false; }
    } },
      U.field('Atividade', tit), U.field('Equipamento ou TAG', eq),
      h('div', { class: 'row2' }, U.field('Tipo', tipo), U.field('Prioridade', pri)),
      h('div', { class: 'row2' }, U.field('Data', dt), U.field('Responsável', resp)),
      U.field('Nº da OS (opcional)', num), U.field('Descrição (opcional)', desc),
      btn, err);
    U.openSheet(edicao ? 'Editar atividade' : 'Nova atividade', form);
  }

  /* ---------- equipe (PCM) ---------- */
  function viewEquipe() {
    var box = h('div', {});
    box.append(h('div', { class: 'team-head' },
      h('h2', {}, 'Equipe'),
      h('button', { class: 'btn', onclick: abrirNovoUsuario }, '+ Novo usuário')));
    var lista = S.users.slice().sort(function (a, b) {
      var pa = a.funcao === 'pcm' ? 0 : 1, pb = b.funcao === 'pcm' ? 0 : 1;
      return pa - pb || a.nome.localeCompare(b.nome, 'pt-BR');
    });
    box.append(h('div', { class: 'list', style: 'margin-top:14px' }, lista.map(function (u) {
      return h('button', { type: 'button', class: 'member', onclick: function () { abrirUsuario(u.id); } },
        h('div', {}, h('div', { class: 'it-t' }, u.nome), h('div', { class: 'it-m' }, h('span', { class: 'mono' }, u.matricula), h('span', {}, U.funcLabel(u.funcao)))),
        u.ativo ? h('span', { class: 'pill ok' }, 'Ativo') : h('span', { class: 'pill' }, 'Inativo'));
    })));
    return box;
  }

  function abrirNovoUsuario() {
    var nome = U.inp('u-nome', { type: 'text', maxlength: '60', autocomplete: 'off' });
    var mat = U.inp('u-mat', { type: 'text', maxlength: '40', autocomplete: 'off', autocapitalize: 'off' });
    var pin = U.inp('u-pin', { type: 'text', inputmode: 'numeric', maxlength: '8', autocomplete: 'off' });
    var papel = U.sel('u-papel', U.FUNCOES.concat([['pcm', 'PCM']]), 'mecanico');
    var err = h('p', { class: 'err', role: 'alert' });
    var btn = h('button', { type: 'submit', class: 'btn block' }, 'Cadastrar');
    U.openSheet('Novo usuário', h('form', { onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (!nome.value.trim()) return (err.textContent = 'Informe o nome.');
      if (!mat.value.trim()) return (err.textContent = 'Informe a matrícula.');
      if (!/^\d{4,8}$/.test(pin.value)) return (err.textContent = 'O PIN precisa ter de 4 a 8 números.');
      btn.disabled = true;
      try {
        await api.post('/usuarios', { nome: nome.value.trim(), matricula: mat.value.trim(), funcao: papel.value, pin: pin.value });
        U.closeSheet(); U.toast('Usuário cadastrado.'); recarregar();
      } catch (x) { err.textContent = x.message; btn.disabled = false; }
    } },
      U.field('Nome', nome), U.field('Matrícula', mat, 'É o que a pessoa digita para entrar.'),
      U.field('PIN inicial', pin, 'De 4 a 8 números. Combine com a pessoa e peça para trocar em “Meu PIN”.'),
      U.field('Função', papel), btn, err));
  }

  function abrirUsuario(id) {
    var u = S.users.filter(function (x) { return x.id === id; })[0]; if (!u) return;
    var eu = u.id === S.user.id;

    var nome = U.inp('e-nome', { type: 'text', maxlength: '60', autocomplete: 'off', value: u.nome });
    var papel = U.sel('e-papel', U.FUNCOES.concat([['pcm', 'PCM']]), u.funcao);
    papel.disabled = eu;
    var err1 = h('p', { class: 'err', role: 'alert' });
    var b1 = h('button', { type: 'submit', class: 'btn ghost block' }, 'Salvar nome e função');
    var f1 = h('form', { onsubmit: async function (e) {
      e.preventDefault(); err1.textContent = '';
      b1.disabled = true;
      try {
        var corpo = { nome: nome.value.trim() };
        if (!eu) corpo.funcao = papel.value;
        await api.patch('/usuarios/' + id, corpo);
        U.closeSheet(); U.toast('Dados salvos.'); recarregar();
      } catch (x) { err1.textContent = x.message; b1.disabled = false; }
    } }, U.field('Nome', nome), U.field('Função', papel), b1, err1);

    var pin = U.inp('r-pin', { type: 'text', inputmode: 'numeric', maxlength: '8', autocomplete: 'off' });
    var err2 = h('p', { class: 'err', role: 'alert' });
    var b2 = h('button', { type: 'submit', class: 'btn block' }, 'Salvar novo PIN');
    var f2 = h('form', { onsubmit: async function (e) {
      e.preventDefault(); err2.textContent = '';
      if (!/^\d{4,8}$/.test(pin.value)) return (err2.textContent = 'O PIN precisa ter de 4 a 8 números.');
      b2.disabled = true;
      try {
        await api.post('/usuarios/' + id + '/pin', { pin: pin.value });
        U.closeSheet(); U.toast('PIN redefinido.');
        if (eu) { api.guardarToken(null); saiu('Seu PIN foi trocado. Entre de novo.'); }
      } catch (x) { err2.textContent = x.message; b2.disabled = false; }
    } }, U.field('Novo PIN', pin, 'O PIN antigo deixa de funcionar na hora.'), b2, err2);

    var alternar = h('button', { type: 'button', class: 'btn ' + (u.ativo ? 'danger' : '') + ' block', disabled: eu, onclick: async function () {
      alternar.disabled = true;
      try {
        await api.patch('/usuarios/' + id, { ativo: !u.ativo });
        U.closeSheet(); U.toast(u.ativo ? 'Usuário desativado.' : 'Usuário reativado.'); recarregar();
      } catch (x) { U.toast(x.message, true); alternar.disabled = false; }
    } }, u.ativo ? 'Desativar usuário' : 'Reativar usuário');

    U.openSheet(u.nome, h('div', {},
      h('dl', { class: 'kv' }, h('dt', {}, 'Matrícula'), h('dd', { class: 'mono' }, u.matricula), h('dt', {}, 'Função'), h('dd', {}, U.funcLabel(u.funcao))),
      f1,
      h('div', { style: 'margin-top:18px' }, f2),
      h('div', { class: 'actions' }, alternar),
      eu ? h('p', { class: 'hint', style: 'margin-top:10px' }, 'Você não pode desativar o seu próprio acesso nem mudar a sua função.')
         : h('p', { class: 'hint', style: 'margin-top:10px' }, 'Usuário desativado não entra no sistema, mas o histórico das atividades dele continua.')));
  }

  function abrirMeuPin() {
    var atual = U.inp('p-atual', { type: 'password', inputmode: 'numeric', maxlength: '8', autocomplete: 'current-password' });
    var novo = U.inp('p-novo', { type: 'password', inputmode: 'numeric', maxlength: '8', autocomplete: 'new-password' });
    var err = h('p', { class: 'err', role: 'alert' });
    var btn = h('button', { type: 'submit', class: 'btn block' }, 'Trocar PIN');
    U.openSheet('Trocar meu PIN', h('form', { onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (!atual.value) return (err.textContent = 'Informe o PIN atual.');
      if (!/^\d{4,8}$/.test(novo.value)) return (err.textContent = 'O novo PIN precisa ter de 4 a 8 números.');
      btn.disabled = true;
      try {
        var r = await api.post('/auth/pin', { atual: atual.value, novo: novo.value });
        api.guardarToken(r.token);
        U.closeSheet(); U.toast('PIN alterado.');
      } catch (x) { err.textContent = x.message; btn.disabled = false; }
    } }, U.field('PIN atual', atual), U.field('Novo PIN', novo, 'De 4 a 8 números.'), btn, err));
  }

  /* ================= início ================= */
  async function iniciar() {
    S.tela = 'carregando'; S.ultimaTela = ''; render();
    try {
      var setup = await api.get('/setup');
      if (api.temToken()) {
        try {
          var eu = await api.get('/auth/eu');
          return entrou(eu.usuario);
        } catch (e) {
          if (e.rede) throw e;
          api.guardarToken(null); // login vencido: segue para a tela de entrada
        }
      }
      S.tela = setup.configurado ? 'login' : 'setup'; S.ultimaTela = ''; render();
    } catch (e) {
      S.tela = 'erro'; S.erro = e.message; S.ultimaTela = ''; render();
    }
  }
  iniciar();
})();
