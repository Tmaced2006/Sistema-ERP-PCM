/* Conversa com o backend. Todas as chamadas passam por aqui. */
(function () {
  'use strict';
  var CHAVE = 'pcm_token';
  var token = null;
  try { token = localStorage.getItem(CHAVE); } catch (e) { /* navegador sem armazenamento */ }
  var aoExpirar = function () {};

  function guardar(t) {
    token = t || null;
    try {
      if (token) localStorage.setItem(CHAVE, token); else localStorage.removeItem(CHAVE);
    } catch (e) { /* segue sem guardar */ }
  }

  async function chamar(metodo, caminho, corpo) {
    var cab = { 'Content-Type': 'application/json' };
    if (token) cab.Authorization = 'Bearer ' + token;
    var res;
    try {
      res = await fetch('/api' + caminho, { method: metodo, headers: cab, body: corpo ? JSON.stringify(corpo) : undefined });
    } catch (e) {
      throw { rede: true, message: 'Sem conexão com o servidor. Confira a internet e tente de novo.' };
    }
    var json = null;
    try { json = await res.json(); } catch (e) { /* resposta sem corpo */ }
    if (!res.ok) {
      var msg = (json && json.erro) || 'Não foi possível concluir. Tente de novo.';
      // Login vencido ou desativado: volta para a tela de entrada.
      if (res.status === 401 && token && caminho !== '/auth/login') {
        guardar(null);
        aoExpirar(msg);
      }
      throw { status: res.status, message: msg };
    }
    return json;
  }

  window.PCM = window.PCM || {};
  window.PCM.api = {
    temToken: function () { return !!token; },
    guardarToken: guardar,
    aoExpirar: function (fn) { aoExpirar = fn; },
    get: function (c) { return chamar('GET', c); },
    post: function (c, b) { return chamar('POST', c, b || {}); },
    patch: function (c, b) { return chamar('PATCH', c, b || {}); },
    del: function (c) { return chamar('DELETE', c); }
  };
})();
